package com.capgemini.merchantstore.services;

import java.util.List;

import com.capgemini.merchantstore.beans.Merchant;
import com.capgemini.merchantstore.beans.Product;
import com.capgemini.merchantstore.exceptions.MerchantNotFoundException;
import com.capgemini.merchantstore.exceptions.ProductNotFoundException;

public interface IMerchantService {
	public Merchant addMerchant(Merchant merchant);
	public Merchant updateMerchant(Merchant merchant);
	public Merchant deleteMerchant(String username);
	public Merchant getMerchant(String username) throws MerchantNotFoundException;
	public Merchant getMerchantById(int merchantId);
	public void changePassword(Merchant merchant,String password);
	
	
	public Product addProduct(Product product) throws ProductNotFoundException;
	public List<Product> getAllProducts(int merchantId);
	public void updateProduct(Product product)throws ProductNotFoundException;
	public Product getProductDetails(int productId);
	public void removeProduct(int productId);
	public Merchant findMerchantId(int merchantId);	
}
