package com.capgemini.merchantstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.merchantstore.beans.Merchant;
import com.capgemini.merchantstore.beans.Product;
import com.capgemini.merchantstore.exceptions.ProductNotFoundException;
import com.capgemini.merchantstore.services.IMerchantService;

@RestController
public class MerchantController {
	
	@Autowired
	IMerchantService MerchantServices;
	
	@RequestMapping(value="/merchantSignIn",method=RequestMethod.POST)
	public void addMerchant(@RequestBody Merchant merchant) {
		
		merchant = MerchantServices.addMerchant(merchant);		
	}
	
	@RequestMapping(value = "/ProductSuccessPage/{merchantId}",method=RequestMethod.POST)
	public void addProduct(@PathVariable("merchantId") int merchantId,@RequestBody Product product) throws ProductNotFoundException {
		
		Merchant merchant = new Merchant(merchantId);
		product.setMerchant(merchant);
		product = MerchantServices.addProduct(product);
	}
	
	
	@RequestMapping(value="addProduct", method=RequestMethod.POST)
	public void getAddProductPage(@RequestBody Product product) throws ProductNotFoundException {
		
		MerchantServices.addProduct(product);
		
	}
	
	@RequestMapping(value = "removedProduct")
	public void removeProduct(int productId) {

		MerchantServices.removeProduct(productId);
	}
	@RequestMapping(value ="updateProduct",method=RequestMethod.POST)
	public void updateProduct(@RequestBody Product product) throws ProductNotFoundException {
		MerchantServices.updateProduct(product);
	}
	@RequestMapping(value="myProfilesuccess")
	public Merchant myProfile( int merchantId ) {
	Merchant merchant = MerchantServices.findMerchantId(merchantId);
	return merchant;
	}
	
	/*@RequestMapping(value="updateProduct")
	public ModelAndView getUpdateProductPage(@ModelAttribute("product") Product product,@RequestParam("abc")int merchantId) {
		System.out.println(merchantId);
		return new ModelAndView("updateProduct","merchantId",merchantId);	
	}*/
//	
//	@RequestMapping(value = "updateProductSuccess/{merchantId}")
//	public ModelAndView updateProduct(@PathVariable int merchantId, @RequestParam("productId") int productId) {
//		Product product = new Product();
//		product = MerchantServices.getProductDetails(productId);
//		return new ModelAndView("addProduct", "product",product);
//		
//	}
//	
////	@RequestMapping(value="updateProduct")
////	public ModelAndView getUpdateProductPage(@ModelAttribute("product") Product product, @RequestParam("abc")int merchantId) {
////		System.out.println(merchantId);
////		return new ModelAndView("updateProduct","merchantId",merchantId);	
////	}
////	
////	@RequestMapping(value="updated/{merchantId}")
////	public ModelAndView getUpdatedPage(@PathVariable int merchantId, @ModelAttribute("product") Product product) {
////		return new ModelAndView("updatedProduct","merchantId",merchantId);	
////	}
//	
	@RequestMapping(value = "getAllProducts", method=RequestMethod.GET)
	public List<Product> getAllProduct() {
		
		return MerchantServices.getAllProducts();
	}
//	
//	public ModelAndView forgotPassword(@RequestParam("username") String username) {
//		Merchant merchant = null;s
//		String securityQuestion = null;
//		try {
//			merchant = MerchantServices.getMerchant(username);
//			securityQuestion = merchant.getSecurityQuestion();
//			
//		} catch (MerchantNotFoundException e) {
//			new ModelAndView("errorPage","error",e.getMessage());
//			e.printStackTrace();
//		}
//		return new ModelAndView("securityQuestion","merchant",securityQuestion);
//	}
//	
//	public ModelAndView securityAnswer(@RequestParam("username") String username, @RequestParam("securityAnswer") String answer) {
//		Merchant merchant = null;
//		try {
//			merchant = MerchantServices.getMerchant(username);
//			if(merchant.getSecurityAnswer().compareTo(answer) == 0) {
//				return new ModelAndView("securityAnswer","message",merchant.getPassword());
//			}
//		} catch (MerchantNotFoundException e) {
//			new ModelAndView("errorPage","error",e.getMessage());
//			e.printStackTrace();
//		}
//		String message = "Not a valid user";
//		return new ModelAndView("InvalidUserPage","message",message);
//	}
//	
////	@RequestMapping(value="changePassword")
////	public ModelAndView changePassword(@RequestParam("abc")int merchantId, @RequestParam("oldPassword")String oldPassword, @RequestParam("newPassword")String newPassword, @RequestParam("confirmNewPassword")String confirmNewPassword ) {
////		Merchant merchant = MerchantServices.getMerchantById(merchantId);
////		if(merchant.getPassword().compareTo(oldPassword) == 0) {
////			MerchantServices.changePassword(merchant, newPassword);
////		}
////		return new ModelAndView("changePasswordSuccess");
////	}
//
//	@RequestMapping(value="changePassword1")
//	public ModelAndView changePassword(@RequestParam("merchantId") int merchantId) {
//	return new ModelAndView("changePassword","merchantId",merchantId);
//	}
//
//	@RequestMapping(value="changePasswordSuccess1/{merchantId}")
//	public ModelAndView changePasswordSuccess(@PathVariable int merchantId, @RequestParam("oldPassword")String oldPassword,@RequestParam("newPassword")String newPassword,@RequestParam("confirmNewPassword")String confirmNewPassword ) {
//	Merchant merchant = MerchantServices.findMerchantId(merchantId);
//	MerchantServices.changePassword(merchant, newPassword);
//	System.out.println(merchant.getPassword());
//	return new ModelAndView("changePasswordSuccess");
//	}
//	@RequestMapping(value="myProfilesuccess")
//	public ModelAndView myProfile(@RequestParam("merchantId") int merchantId ) {
//	Merchant merchant = MerchantServices.findMerchantId(merchantId);
//	return new ModelAndView("myProfilesuccess", "merchant", merchant);
//	}
//*/
}
